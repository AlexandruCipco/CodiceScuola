package p257_n35;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("\n--- Docenti ---");	
		Docenti d=new Docenti();
		d.leggiDocenti();
		d.stampaDocenti();
		
		System.out.println("\n--- Impiegati ---");	     
		Impiegati i=new Impiegati();
		i.leggiImpiegati();
		i.stampaImpiegati();
		
		System.out.println("\n--- Impiegati Straordinari ---");	     
		ImpiegatiStraordinari is=new ImpiegatiStraordinari();
		is.leggiImpiegatiStraordinari();
		is.stampaImpiegatiStraordinari();
		
		
	     System.out.println("\nAggiornamento retribuzione oraria straordinari: 21.00 euro");
	     ImpiegatoStraordinari.setRetribuzione_oraria_straordinari(21.00);
	    
	}

}
