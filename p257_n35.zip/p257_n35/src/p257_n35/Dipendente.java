package p257_n35;

public abstract class Dipendente {
	 protected String nominativo;
	 protected String sesso;
	 protected String data_nascita;
	 protected int stipendio;

	    public Dipendente(String nominativo, String sesso, String data_nascita, int stipendio) {
	        this.nominativo = nominativo;
	        this.sesso = sesso;
	        this.data_nascita = data_nascita;
	        this.stipendio = stipendio;
	    }

	    public int getStipendio() {
	        return stipendio;
	    }

	    public void setStipendio(int stipendio) {
	        this.stipendio = stipendio;
	    }

	    public String getData_nascita() {
	        return data_nascita;
	    }

	    public void setData_nascita(String data_nascita) {
	        this.data_nascita = data_nascita;
	    }

	    public String getNominativo() {
	        return nominativo;
	    }

	    public void setNominativo(String nominativo) {
	        this.nominativo = nominativo;
	    }

	    public String getSesso() {
	        return sesso;
	    }

	    public void setSesso(String sesso) {
	        this.sesso = sesso;
	    }
	 
	 
	 public String toString (){
	     return "Nome: "+ nominativo+" Sesso: "+ sesso+ " data_nascita: "+data_nascita+" Stipendio base: "+stipendio;
	 }
	 public boolean equals (Dipendente dipendente){
	     return ((dipendente.getNominativo().equals(nominativo)) &&
	              (dipendente.getData_nascita().equals(data_nascita))&&
	              (dipendente.getSesso().equals(sesso)) &&
	              (dipendente.getStipendio()==stipendio));
	 }
	}