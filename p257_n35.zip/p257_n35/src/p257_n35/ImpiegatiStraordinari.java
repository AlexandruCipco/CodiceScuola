package p257_n35;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ImpiegatiStraordinari {
	private ImpiegatoStraordinari[] listaImpiegatiStraordinari;
	private int nis=0;
	
	public ImpiegatiStraordinari() {
		listaImpiegatiStraordinari=new ImpiegatoStraordinari[100];
	}
	
	public void addImpiegatiStraordinari(ImpiegatoStraordinari impiegatoStraordinari) {
		listaImpiegatiStraordinari[nis]=impiegatoStraordinari;
		nis++;
	}
	
	public void leggiImpiegatiStraordinari() throws IOException {
		BufferedReader reader=new BufferedReader(new FileReader("ImpiegatoStraordinari.txt"));
		String riga;
		
		while((riga=reader.readLine())!= null) {
			String[] rigaSplittata=riga.split(";");
			ImpiegatoStraordinari is=new ImpiegatoStraordinari(rigaSplittata[0], 
				rigaSplittata[1], 
				rigaSplittata[2],
				Integer.parseInt(rigaSplittata[3]),
				rigaSplittata[4],
				rigaSplittata[5],
				Integer.parseInt(rigaSplittata[6]));
			addImpiegatiStraordinari(is);
		}
	}
	
	public void stampaImpiegatiStraordinari() {
		for(int i=0;i<nis;i++) {
			listaImpiegatiStraordinari[i].stampaImpiegatoStraordinari();	
		}
	}
}
