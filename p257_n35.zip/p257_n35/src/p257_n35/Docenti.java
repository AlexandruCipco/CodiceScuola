package p257_n35;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Docenti {
	private Docente[] listaDocenti;
	private int nd=0;
	
	public Docenti() {
		listaDocenti=new Docente[100];
	}
	
	public void addCampioni(Docente docente) {
		listaDocenti[nd]=docente;
		nd++;
	}
	
	public void leggiDocenti() throws IOException {
		BufferedReader reader=new BufferedReader(new FileReader("Docente.txt"));
		String riga;
		
		while((riga=reader.readLine())!= null) {
			String[] rigaSplittata=riga.split(";");
			Docente d=new Docente(rigaSplittata[0], 
				rigaSplittata[1], 
				rigaSplittata[2],
				rigaSplittata[3],
				rigaSplittata[4],
				Integer.parseInt(rigaSplittata[5]),
				Integer.parseInt(rigaSplittata[6]));
			addCampioni(d);
		}
	}
	
	public void stampaDocenti() {
		for(int i=0;i<nd;i++) {
			listaDocenti[i].stampaDocente();	
		}
	}
}
