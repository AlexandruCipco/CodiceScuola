package p257_n35;

public class ImpiegatoStraordinari extends Impiegato {
    private int ore_straordinario;
    private static double retribuzione_oraria_straordinari=20.0;

    public ImpiegatoStraordinari(String nominativo, String sesso, String data_nascita, int stipendio, String ufficio, String livello, int ore_straordinario) {
        super(nominativo, sesso, data_nascita, stipendio, ufficio, livello);
        this.ore_straordinario = ore_straordinario;
    }
    
    public void stampaImpiegatoStraordinari() {
		System.out.println(nominativo);
		System.out.println(sesso);
		System.out.println(data_nascita);
		System.out.println(stipendio);
		System.out.println(ufficio);
		System.out.println(livello);	
		System.out.println(ore_straordinario);
	}

    public int getOre_straordinario() {
        return ore_straordinario;
    }

    public void setOre_straordinario(int ore_straordinario) {
        this.ore_straordinario = ore_straordinario;
    }

    public static double getRetribuzione_oraria_straordinari() {
        return retribuzione_oraria_straordinari;
    }

    public static void setRetribuzione_oraria_straordinari(double retribuzione_oraria_straordinari) {
    	ImpiegatoStraordinari.retribuzione_oraria_straordinari = retribuzione_oraria_straordinari;
    }
    
    public double importoStraodinari(){
        return (double)ore_straordinario*retribuzione_oraria_straordinari;
    }
    
    public String toString(){
        double stip_totale=stipendio+importoStraodinari();
        return super.toString()+" Ore straordinario: "+ore_straordinario+ " a "+retribuzione_oraria_straordinari+"euro/ora Totale stipendio: "+(stip_totale)+"euro";
    }
    

}
