package p257_n35;

public class Impiegato extends Dipendente {
	 protected String ufficio;
	 protected String livello;

	 public Impiegato(String nominativo, String sesso, String data_nascita, int stipendio, String ufficio, String livello) {
	       super(nominativo, sesso, data_nascita, stipendio);
	       this.ufficio = ufficio;
	       this.livello = livello;
	   }
	 
	 public void stampaImpiegato() {
			System.out.println(nominativo);
			System.out.println(sesso);
			System.out.println(data_nascita);
			System.out.println(stipendio);
			System.out.println(ufficio);
			System.out.println(livello);			
		}
	 
	   public String getLivello() {
	       return livello;
	   }
	    
	   public void setLivello(String livello) {
	       this.livello = livello;
	   }
	    
	   public String getUfficio() {
	       return ufficio;
	   }

	   public void setUfficio(String ufficio) {
	       this.ufficio = ufficio;
	   }
	 
	   
}
