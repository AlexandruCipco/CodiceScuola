package p257_n35;

public class Docente extends Dipendente {
	 private String ruolo;
	 private String disciplina;
	 private int ore_docenza;

	    public Docente(String nominativo, String sesso, String data_nascita, String ruolo, String disciplina, int ore_docenza, int stipendio) {
	        super(nominativo, sesso, data_nascita,stipendio);
	        setRuolo(ruolo);
	        setDisciplina(disciplina);
	        setOre_docenza(ore_docenza);
	    }
	    
	    public void stampaDocente() {
			System.out.println(nominativo);
			System.out.println(sesso);
			System.out.println(data_nascita);
			System.out.println(ruolo);
			System.out.println(disciplina);
			System.out.println(ore_docenza);
			System.out.println(stipendio);
		}

	    public String getDisciplina() {
	        return disciplina;
	    }

	    public void setDisciplina(String disciplina) {
	        this.disciplina = disciplina;
	    }

	    public int getOre_docenza() {
	        return ore_docenza;
	    }

	    public void setOre_docenza(int ore_docenza) {
	        this.ore_docenza = ore_docenza;
	    }

	    public String getRuolo() {
	        return ruolo;
	    }

	    public void setRuolo(String ruolo) {
	        this.ruolo = ruolo;
	    }

	  
	 
	}
