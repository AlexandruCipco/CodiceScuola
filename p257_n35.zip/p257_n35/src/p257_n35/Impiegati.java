package p257_n35;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Impiegati {
	private Impiegato[] listaImpiegati;
	private int ni=0;
	
	public Impiegati() {
		listaImpiegati=new Impiegato[100];
	}
	
	public void addImpiegati(Impiegato impiegato) {
		listaImpiegati[ni]=impiegato;
		ni++;
	}
	
	public void leggiImpiegati() throws IOException {
		BufferedReader reader=new BufferedReader(new FileReader("Impiegato.txt"));
		String riga;
		
		while((riga=reader.readLine())!= null) {
			String[] rigaSplittata=riga.split(";");
			Impiegato i=new Impiegato(rigaSplittata[0], 
				rigaSplittata[1], 
				rigaSplittata[2],
				Integer.parseInt(rigaSplittata[3]),
				rigaSplittata[4],
				rigaSplittata[5]);
			addImpiegati(i);
		}
	}
	
	public void stampaImpiegati() {
		for(int i=0;i<ni;i++) {
			listaImpiegati[i].stampaImpiegato();	
		}
	}
}
